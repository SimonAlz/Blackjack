﻿using ClassLibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Dynamic;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;

namespace BlackJack
{
    class Program
    {
        public static Deck cardDeck { get; set; }

        static void Main(string[] args)
        {
            Program pObject = new Program();
            int selection;
            cardDeck = new Deck();
            String[] choices = { "Play Blackjack", "Shuffle and Show Deck", "Exit" };
            while (true)
            {
                pObject.ReadChoice("Choice? ", choices, out selection);

                switch (selection)
                {
                    case 1: pObject.PlayBlackjack(); break;
                    case 2: pObject.ShuffleShow(cardDeck); break;
                    case 3: return;
                    default: Console.WriteLine("\nYou did not make a valid selection\n"); break;
                }

                Console.Write("\n Press any key to continue ");
                String cont = Console.ReadLine();

                Console.Clear();
            }

        }
        public  void  PlayBlackjack()
        {
            cardDeck = new Deck();
            Console.Clear();
            Hand dealerHand = new Hand();
            cardDeck.Shuffle();
            PlayingCard newCard;
            Hand playerHand = new Hand();
            Console.WriteLine("The game has started...\n");
            for (int i = 0; i < 2; i++)
            {
                newCard = cardDeck.Draw();
                dealerHand.AddCards(newCard);
            }
            Console.WriteLine("The dealer's card is: \n");
            PrintCard(dealerHand.cardsList[0]);
            for (int i = 0; i < 2; i++)
            {
                newCard = cardDeck.Draw();
                playerHand.AddCards(newCard);
            }
            Console.WriteLine("\nYour Cards are:\n");
            PrintCard(playerHand.cardsList[0]);
            PrintCard(playerHand.cardsList[1]);
            Console.WriteLine("\nYour score is: " + playerHand.score);
            int selection;
            Program pObject = new Program();
            bool repeat = true;
            do
            {
                String[] choices = { "Hit", "Stay" };
                pObject.ReadChoice("Choice? ", choices, out selection);
                switch (selection)
                {
                    case 1:
                        if (playerHand.score < 21)
                        {
                            newCard = cardDeck.Draw();
                            playerHand.AddCards(newCard);
                            Console.Write("\n");
                            foreach (PlayingCard card in playerHand.cardsList)
                            {
                                PrintCard(card);
                            }
                            Console.WriteLine("\nYour score is: " + playerHand.score);
                            if (playerHand.score < 21)
                            {
                                repeat = true;
                            }
                            else if (playerHand.score == 21)
                            {
                                Console.WriteLine("\nYour score is equal to 21. Press any key to see the results");
                                Console.ReadKey();
                                goto case 2;
                            }
                            else
                            {
                                Console.WriteLine("\nYour score is greater than 21. Press any key to see the results");
                                Console.ReadKey();
                                goto case 2;
                            }
                        }
                        else
                        {
                            Console.WriteLine("You can't get more cards! Press any key to see the results");
                            Console.ReadKey();
                            goto case 2;
                        }
                        break;
                    case 2:
                        while (dealerHand.score < 17)
                        {
                            newCard = cardDeck.Draw();
                            dealerHand.AddCards(newCard);
                        }
                        Console.WriteLine("\nDealer's Hand: \n");
                        foreach (PlayingCard card in dealerHand.cardsList)
                        {
                            PrintCard(card);
                        }
                        Console.WriteLine("Dealer Score: " + dealerHand.score);
                        if (dealerHand.score > playerHand.score && dealerHand.score <= 21)
                        {
                            Console.WriteLine("\nThe dealer has won!");
                        }
                        else if (playerHand.score > dealerHand.score && dealerHand.score <= 21 && playerHand.score > 21)
                        {
                            Console.WriteLine("\nThe dealer has won!");
                        }
                        else if (playerHand.score > dealerHand.score && playerHand.score <= 21)
                        {
                            Console.WriteLine("\nYou have won!");
                        }
                        else if (dealerHand.score > playerHand.score && playerHand.score <= 21 && dealerHand.score > 21)
                        {
                            Console.WriteLine("\nYou have won!");
                        }
                        else if (playerHand.score == dealerHand.score && playerHand.score <= 21 && dealerHand.score <= 21)
                        {
                            Console.WriteLine("\nYou have tied with the dealer!");
                        }
                        else if (playerHand.score > 21 && dealerHand.score > 21)
                        {
                            Console.WriteLine("\nYou and the dealer have busted, nobody wins!");
                        }
                        repeat = false;
                        break;
                    default: Console.WriteLine("\nYou did not make a valid selection\n"); break;
                }
            } while (repeat);
        }
        public void PrintCard(PlayingCard shownCard)
        {
            string spacing;
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            if (shownCard.Face == "10")
            {
                spacing = " ";
            }
            else
            {
                spacing = "  ";
            }
            if (shownCard.Suit == '♦' || shownCard.Suit == '♥')
                {
                    Console.BackgroundColor = ConsoleColor.White;
                    Console.ForegroundColor = ConsoleColor.Red;
                    if (shownCard.Suit == '♦')
                    {
                        Console.Write($"{shownCard.Face}" + spacing + $"{"\u2666"}");
                    }
                    else
                    {
                        Console.Write($"{shownCard.Face}" + spacing + $"{"\u2665"}");
                    }
                    Console.WriteLine(" \n     \n     \n");
                    Console.BackgroundColor = ConsoleColor.Black;
                    Console.ForegroundColor = ConsoleColor.White;
                }
                else if (shownCard.Suit == '♣' || shownCard.Suit == '♠')
                {
                    Console.BackgroundColor = ConsoleColor.White;
                    Console.ForegroundColor = ConsoleColor.Black;
                    if (shownCard.Suit == '♣')
                    {
                        Console.Write($"{shownCard.Face}" + spacing + $"{"\u2663"}");
                    }
                    else
                    {
                        Console.Write($"{shownCard.Face}" + spacing + $"{"\u2660"}");
                    }
                    Console.WriteLine(" \n     \n     \n");
                    Console.BackgroundColor = ConsoleColor.Black;
                    Console.ForegroundColor = ConsoleColor.White;
                }
            
        }
        public void ShuffleShow(Deck deck)
        {
            cardDeck = new Deck();
            cardDeck.Shuffle();
            cardDeck.ShowCards();
        }
        public void ReadChoice(String prompt, String[] options, out int selection)
        {
            for (int i = 0; i < options.Length; i++)
            {
                Console.WriteLine("\n " + (i + 1) + " - " + options[i]);
            }

            Console.WriteLine("\n\n");
            selection = ReadInteger(prompt);
        }
        public static int ReadInteger(String prompt)
        {
            try
            {
                Console.WriteLine(prompt);
                int n = Convert.ToInt32(Console.ReadLine());
                return n;
            }
            catch (Exception ex)
            {
                Console.WriteLine("This is not an integer. Please try again.");
                return ReadInteger(prompt);
            }
        }
    }
}