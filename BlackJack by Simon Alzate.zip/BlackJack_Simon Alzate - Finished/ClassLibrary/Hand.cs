﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Hand
    {
        public List<PlayingCard> cardsList { get; set; }
        public int score { get; set; }
        public Hand()
        {
            cardsList = new List<PlayingCard>();
            score = 0;
        }

        public void AddCards(PlayingCard addedCard)
        {
            int auxiliarScore = 0;
            cardsList.Add(addedCard);
            int aceAmount = 0;
            foreach (PlayingCard playerCard in cardsList)
            {
                if (playerCard.Face == "A")
                {
                    aceAmount = aceAmount + 1;
                }
            }
            if (aceAmount == 0)
            {
                foreach (PlayingCard playerCard in cardsList)
                {
                    auxiliarScore = score + playerCard.Value[0];
                }
            }
            else
            {
                if (aceAmount == 1)
                {
                    foreach (PlayingCard playerCard in cardsList)
                    {
                        auxiliarScore = score + playerCard.Value[0];
                    }
                    if (auxiliarScore > 21)
                    {
                        auxiliarScore = 0;
                        foreach (PlayingCard playerCard in cardsList)
                        {
                            if (playerCard.Face == "A")
                            {
                                auxiliarScore = score + playerCard.Value[1];

                            }
                            else
                            {
                                auxiliarScore = score + playerCard.Value[0];
                            }
                        }
                    }
                }
                else
                {
                    foreach (PlayingCard playerCard in cardsList)
                    {
                        if(playerCard.Face == "A")
                        {
                            auxiliarScore = score + playerCard.Value[0];
                            if (auxiliarScore > 21)
                            {
                                auxiliarScore = score - playerCard.Value[0] + playerCard.Value[1];
                            }
                        }
                        else
                        {
                            auxiliarScore = score + playerCard.Value[0];
                        }
                    }
                }
            }
            score = auxiliarScore;
        }
    }
}
