﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class PlayingCard
    {
        public string Face { get; set;}
        public int[] Value { get; set;}
        public char Suit { get; set;}

        public PlayingCard(string face, char suit)
        {
            Face = face;
            Suit = suit;
            Value = DeterminateValue(Face);
        }
        public static int[] DeterminateValue(string _face)
        {
            string[] faceOptions = { "A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "K", "Q" };
            int[] valueOptions = {0,2,3,4,5,6,7,8,9,10,10,10,10};
            for(int i = 0; i < faceOptions.Length; i++)
            {
                if(_face == faceOptions[i])
                {
                    if(i == 0)
                    {
                        int[] valueReturn1 = {11,1};
                        return valueReturn1;
                    }
                    int[] valueReturn = { valueOptions[i] };
                    return valueReturn;
                }
            }
            return null;
        }

    }
}
