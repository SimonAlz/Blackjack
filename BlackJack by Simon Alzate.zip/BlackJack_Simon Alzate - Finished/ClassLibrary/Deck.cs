﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace ClassLibrary
{
    public class Deck
    {
        public List<PlayingCard> theCards { get; set; } = new List<PlayingCard>();


        public Deck()
        {
            theCards = CreateCards();
        }
        public List<PlayingCard> CreateCards()
        {
            List<PlayingCard> auxiliar = new List<PlayingCard>();
            char[] symbol = { '♣', '♠', '♦', '♥' };
            string[] faces = { "A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "K", "Q" };
            PlayingCard newCard;
            for (int i = 0; i <= 3; i++)
            {
                for (int a = 0; a < 13; a++)
                {
                   newCard = new PlayingCard(faces[a], symbol[i]);
                   auxiliar.Add(newCard);
                }
            }
            return auxiliar;
        }
        public void Shuffle()
        {
            List<PlayingCard> oldCards = new List<PlayingCard>();
            var randomNumber = new Random();
            int[] numbers = new int[52];
            int _number;
            PlayingCard card;
            for (int s = 0; s < 51; s++)
            {
                do
                {
                    _number = randomNumber.Next(0, 52);
                } while (Repeated(numbers, _number));
                numbers[s] = _number;
            }


            foreach (PlayingCard card1 in theCards)
            {
                oldCards.Add(card1);
            }
            for (int i = 0; i < 52; i++)
            {
                card = oldCards[numbers[i]];
                theCards[i] = card;
                
            }
            Console.BackgroundColor = ConsoleColor.Black;
        }

        public bool Repeated(int[] numbers, int number)
        {
            for (int i = 0; i < numbers.Length; i++)
                if (number == numbers[i])
                    return true;
            return false;
        }

        public PlayingCard Draw()
        {
            int a = 0;
            bool control = true;
            do
            {
                if (theCards[a] == null && a <= 51)
                {
                    a++;
                }
                else
                {
                    control = false;
                }

            } while (control);
            if (a >= 51)
            {
                Console.WriteLine("There's no more cards in the deck!");
                return null;
            }
            PlayingCard returnedCard = theCards[a];
            theCards[a] = null;
            return (returnedCard);
        }

        public PlayingCard VerifyNumber()
        {
            return null;
        }

        public void ShowCards()
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            string spacing;
            foreach (PlayingCard card in theCards)
            {
                if (card.Face == "10")
                {
                    spacing = " ";
                }
                else
                {
                    spacing = "  ";
                }
                if (card.Suit == '♦' || card.Suit == '♥')
                {
                    Console.BackgroundColor = ConsoleColor.White;
                    Console.ForegroundColor = ConsoleColor.Red;
                    
                    if (card.Suit == '♦')
                    {
                        Console.Write($"{card.Face}" + spacing + $"{"\u2666"}");
                    }
                    else
                    {
                        Console.Write($"{card.Face}" + spacing + $"{"\u2665"}");
                    }
                    Console.WriteLine(" \n     \n     \n");
                    Console.BackgroundColor = ConsoleColor.Black;
                    Console.ForegroundColor = ConsoleColor.White;
                }
                else if (card.Suit == '♣' || card.Suit == '♠')
                {
                    Console.BackgroundColor = ConsoleColor.White;
                    Console.ForegroundColor = ConsoleColor.Black;
                    if (card.Suit == '♣')
                    {
                        Console.Write($"{card.Face}" + spacing + $"{"\u2663"}");
                    }
                    else
                    {
                        Console.Write($"{card.Face}" + spacing + $"{"\u2660"}");
                    }
                    Console.WriteLine(" \n     \n     \n");
                    Console.BackgroundColor = ConsoleColor.Black;
                    Console.ForegroundColor = ConsoleColor.White;
                }
            }
        }
    }
}
